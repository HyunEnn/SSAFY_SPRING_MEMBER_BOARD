package edu.ssafy.spring.util;

public class PaggingUtil {
	public static int sizePerPage = 5;
	public static int naviSize = 10;
}
